function attachEvents() {
    // TODO:
}