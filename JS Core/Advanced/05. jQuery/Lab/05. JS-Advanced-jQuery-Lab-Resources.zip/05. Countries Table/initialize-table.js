function initializeTable() {
    // TODO:
}