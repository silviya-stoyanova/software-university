# 04. Responsive Vertical Timeline

## Tasks
* Create an **"index.html"** file with title - **"Responsive Vertical Timeline"**
* Add a list of articles in a section 
* Add **media queries** for the list to look good on **mobile** and **desktop**

## Constraints
* Use **semantic HTML** - section, article, header etc.
