# 02. Responsive Menu

## Tasks
* Create an **"index.html"** file with title - **"Responsive Menu"**
* Copy your multi-level drop down menu
* Add **media queries** to hide the toggle checkbox and label for **desktops**
* Add **media queries** to show the toggle checkbox and label for **mobile devices**

## Constraints
* **Don't** use IDs
