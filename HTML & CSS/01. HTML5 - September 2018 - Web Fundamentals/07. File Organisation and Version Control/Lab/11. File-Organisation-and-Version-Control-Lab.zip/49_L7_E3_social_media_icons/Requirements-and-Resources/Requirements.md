# 03. Social Media Icons

## Tasks
* Create an **"index.html"** file with title - **"Social Media Icons"**
* Get the latest *reset.css*
* Get the latest *typography.css*
* Include **Font Awesome**
* Add social **icons**
