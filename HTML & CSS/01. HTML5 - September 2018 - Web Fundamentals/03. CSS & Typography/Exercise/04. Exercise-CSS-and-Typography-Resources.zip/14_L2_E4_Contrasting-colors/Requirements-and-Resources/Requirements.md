# 04 - Contrasting Colors 

## Tasks
 * Create an **index.html** file with **Contrasting Colors** title 
* Create an **article** inside the body
	* Make the background with **rgb(51, 102, 153)** color
	* Set the border radius to **1rem**
* Use **"Helvetica",sans-serif**  font-family for the document
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
* Use **"Georgia", serif** font-family for the headings