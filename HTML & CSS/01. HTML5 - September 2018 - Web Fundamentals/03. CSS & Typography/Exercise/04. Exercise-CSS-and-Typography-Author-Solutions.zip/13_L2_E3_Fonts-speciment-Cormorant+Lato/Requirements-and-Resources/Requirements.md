# 03 - Fonts Speciment - Cormorant + Lato

## Tasks
 * Create an **index.html** file with **Fonts Speciment - Cormorant + Lato** title 
* Use **"Lato",sans-serif**  font-family for the document
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
* Use **"Cormorant", serif** font-family for the headings
	* Make the **font-size** 1em
	* Change the **line-height** to 1.2
	* Change the font weight to **bold**
