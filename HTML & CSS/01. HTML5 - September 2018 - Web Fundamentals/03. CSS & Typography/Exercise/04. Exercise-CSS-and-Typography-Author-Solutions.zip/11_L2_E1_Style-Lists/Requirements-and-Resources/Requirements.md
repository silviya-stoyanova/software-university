# 01 - Style Lists

## Tasks
 * Create an **index.html** file with **Style Lists** title 
	* Use **font-family: 'Helvetica, sans-serif'**, with **font-size: 16px** and **line-height: 1.5**
