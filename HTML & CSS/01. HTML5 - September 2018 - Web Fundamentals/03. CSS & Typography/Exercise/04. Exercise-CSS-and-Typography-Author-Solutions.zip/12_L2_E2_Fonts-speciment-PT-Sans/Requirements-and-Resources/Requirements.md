# 02 - Fonts Speciment PT Sans

## Tasks
 * Create an **index.html** file with **Fonts Speciment PT Sans** title 
	* Use **PT Sans font-family**
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
