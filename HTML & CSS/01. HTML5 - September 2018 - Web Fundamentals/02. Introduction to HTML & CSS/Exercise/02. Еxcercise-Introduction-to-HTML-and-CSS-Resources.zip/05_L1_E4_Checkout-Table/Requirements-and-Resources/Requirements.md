# 05 - Checkout Table

## Constraints
 * Change the **title**
 * Use **span** tag with value **checked** for checked items