# 01 - My first HTML Page

### Constraints
 * Create "index.html" document
 * Change the **title**
 * Use **p** tag for plain text and **strong** tag for bold text