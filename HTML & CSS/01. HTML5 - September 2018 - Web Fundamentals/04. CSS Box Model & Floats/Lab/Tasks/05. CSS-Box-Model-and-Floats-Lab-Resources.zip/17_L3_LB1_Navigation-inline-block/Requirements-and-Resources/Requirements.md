# 01. Navigation Inline Block

## Tasks
 * Create an **"index.html"** and **"style.css"** files
 * Change the **title** to **Navigation Inline Block**
 * Create a **header**  with **navigation bar** inside
	* Add **display: inline-block;** style for each item in the **nav**
	
## Constraints
 * Fonts
	* Font family **"Helvetica", sans-serif** with font size **16px** and line height **1.2** for the **html**
	* Font family **"Georgia", sans-serif** with font size **1em** and line height **1.2** for the **headings**






