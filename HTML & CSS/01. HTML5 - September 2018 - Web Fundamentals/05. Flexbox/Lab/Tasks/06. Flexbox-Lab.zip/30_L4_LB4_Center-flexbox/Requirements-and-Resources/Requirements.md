# 04. Center Flexbox

## Tasks
 * Create an **"index.html"** file with title - **"Center Flexbox"**


## Constraints
 * The document **background** color has to be **rgb(238, 238, 238)**
 * The body **display** propery has to be **flex**
 * The **content** must be placed into **div** with **class card** *(div.card)*
 * The text **color** in the card **container** has to be **rgb(255, 255, 255)**




