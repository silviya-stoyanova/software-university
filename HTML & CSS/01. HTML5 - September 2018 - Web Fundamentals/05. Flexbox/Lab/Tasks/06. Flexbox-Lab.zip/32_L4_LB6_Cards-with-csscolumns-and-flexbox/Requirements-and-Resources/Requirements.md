# 06. Cards with CSS Columns and Flexbox

## Tasks
 * Create an **"index.html"** with title - **"Cards with CSS Columns and Flexbox"**
 * Use the images from the **resources** folder
 
## Constraints
 * Body **background color** must be **rgb(238, 238, 238)**
 * The **content** should be divided in two parts:
	* First part is container unit **(div)** with classes **cards-layout** and **masonry**
	* Second part is is container unit **(div)** with classes **cards-layout** and **flex**
